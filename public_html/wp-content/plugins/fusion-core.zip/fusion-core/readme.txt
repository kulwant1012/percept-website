=== Avada Core ===
Requires at least: 4.5
Requires PHP: 5.6
