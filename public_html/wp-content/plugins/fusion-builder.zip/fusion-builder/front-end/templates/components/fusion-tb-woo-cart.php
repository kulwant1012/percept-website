<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.2
 */

?>
<script type="text/html" id="tmpl-fusion_tb_woo_cart-shortcode">
	<div {{{ _.fusionGetAttributes( wrapperAttr ) }}}>
		{{{ output }}}
		{{{ styles }}}
	</div>
</script>
