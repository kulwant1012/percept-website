<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 2.0
 */

?>
<script type="text/html" id="tmpl-fusion_tooltip-shortcode">
	<span {{{ _.fusionGetAttributes( attr ) }}}>{{{ FusionPageBuilderApp.renderContent( content, cid, false ) }}}</span>
</script>
