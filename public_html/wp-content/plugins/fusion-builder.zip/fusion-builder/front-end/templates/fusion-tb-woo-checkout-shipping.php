<?php
/**
 * Underscore.js template
 *
 * @package fusion-builder
 * @since 3.3
 */

?>
<script type="text/html" id="tmpl-fusion_tb_woo_checkout_shipping-shortcode">
	<div {{{ _.fusionGetAttributes( wrapperAttr ) }}}>
		{{{ styles }}}
		{{{output}}}
	</div>
</script>
